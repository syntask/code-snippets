// Log "testing" every 2 seconds
setInterval(function() {
    console.log("testing");
}, 2000);